#!/bin/bash


# pre setup checks / variable definitions
homedir=$HOME
echo "home directory: $homedir"
read -p "confirm (y/n): " yn
if [ "$yn" == "y" ]; then
echo "home directory confirmed"
else
echo "enter home directory"
read homedir
echo "home directory: $homedir"
read -p "confirm (y/n): " yn
if [ "$yn" == "y" ]; then
if [ -d "$homedir" ]; then
echo "home directory confirmed"
else
echo "ERROR: "$homedir" is not a valid directory"
exit 0
fi
else
echo "home directory unknown, aborting"
exit 0
fi
fi
selfdir=$(pwd)
echo "self directory: $selfdir"
if [ -f "$selfdir"/setup.bash ]; then
echo "found self"
else
echo "could not find self, open terminal in the editpath directory before running setup"
exit 0
fi

if test -f "$homedir"/.bashrc; then
bashdir="$homedir"/.bashrc
echo ".bashrc file found"
else
echo "find your .bashrc file and paste its directory into the console"
read bashdir
if test -f "$homedir"/.bashrc; then
echo ".bashrc file found"
else
echo "ERROR: .bashrc file not found"
exit 0
fi
fi

# setup locations (if they havent been already)
if ! [ -d "$homedir"/.editpath ]; then
echo "directory "$homedir"/.editpath not found"
cp -r ./.editpath $homedir
echo ".editpath directory copied to home"
# backup and edit .bashrc to include editpath command
echo "backing up .bashrc file"
cp $bashdir ./backup/
echo ".bashrc file backed up to $selfdir""/backup/.bashrc"
echo "export PATH=\"""$homedir"/.editpath/bin/":\$PATH\"" >> $bashdir
echo ".bashrc modified, editpath command added to PATH"
else
echo "editpath has already been extracted!"
fi


# pass variables

echo "$homedir"/.editpath/bin/ > "$homedir"/.editpath/customPATH
echo "editpath command directory passed to editpath"
echo $bashdir > "$homedir"/.editpath/heap/dir
echo ".bashrc directory passed to editpath"

echo "

setup complete, restart terminal instance for changes to take effect.

"

exit 1
